<!DOCTYPE html>
<html>
<head>
    @include('includes.admin.header')
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    @include('includes.admin.main-header')
    @include('includes.admin.main-sidebar')
    <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <!-- Main content -->
            <section class="content">
                <h1>No Permission For you </h1>
            </section>
            <!-- /.content -->
        </div>
    @include('includes.admin.footer')
</div>
<!-- ./wrapper -->
@include('includes.admin.script')
</body>
</html>
