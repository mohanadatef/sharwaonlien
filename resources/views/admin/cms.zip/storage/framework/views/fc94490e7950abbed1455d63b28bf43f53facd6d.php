<?php $__env->startSection('title'); ?>
    Edit User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/admin/multi-select.css')); ?>">
    <style>
        .ms-container {
            width: 25%;
        }

        li.ms-elem-selectable, .ms-selected {
            padding: 5px !important;
        }

        .ms-list {
            height: 150px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            User
            <small>Edit User</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i class="fa fa-users"></i>User</a></li>
            <li><a href="<?php echo e(url('/admin/user/edit/'.$data->slug)); ?>"><i class="fa fa-user"></i>Edit User: <?php echo e($data->username); ?></a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>Edit User : <?php echo e($data->username); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id="user_edit" action="<?php echo e(url('admin/user/update/'.$data->slug)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ""); ?>">
                        User Name : <input type="text" class="form-control" name="username" value="<?php echo e($data->username); ?>"
                                           placeholder="Enter You User Name">
                    </div>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ""); ?>">
                        Email : <input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>" placeholder="Enter You Email">
                    </div>
                    <div class="form-group<?php echo e($errors->has('role_id') ? ' has-error' : ""); ?>">
                        Choose Permission :
                        <select id="role_id" multiple='multiple' name="role_id[]">
                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myrole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($myrole->id); ?>"
                                        <?php $__currentLoopData = $role_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myrole_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($myrole_user->role_id ==$myrole->id): ?>){
                                        selected } <?php else: ?>{ }<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> > <?php echo e($myrole->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="Edit">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <script src="<?php echo e(url('public/js/admin/jquery.multi-select.js')); ?>"></script>
    <script>
        $('#role_id').multiSelect();
    </script>
    <?php echo JsValidator::formRequest('Modules\ACL\Http\Requests\admin\User\UserEditRequest','#user_edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\Modules\ACL\Providers/../Resources/views/user/edit.blade.php ENDPATH**/ ?>