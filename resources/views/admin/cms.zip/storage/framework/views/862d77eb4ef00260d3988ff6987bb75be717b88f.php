<?php $__env->startSection('title'); ?>
    Index User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .example-modal .modal {
            position: relative;
            top: auto;
            bottom: auto;
            right: auto;
            left: auto;
            display: block;
            z-index: 1;
        }

        .example-modal .modal {
            background: transparent !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            User
            <small>All User</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i class="fa fa-users"></i> User</a></li>
        </ol>
    </section>
    <section class="content">
        <form method="get" action="<?php echo e(url('/admin/user/change_many_status')); ?>">
        <div class="box">
            <div class="box-header" align="right">
                <?php if (\Entrust::can('user-create')) : ?>
                <a href="<?php echo e(url('/admin/user/create')); ?>" class="btn btn-primary">Create</a>
                <?php endif; // Entrust::can ?>
                <?php if (\Entrust::can('user-many-status')) : ?>
                <input type="submit" value="Change Status" class="btn btn-primary">
                <?php endif; // Entrust::can ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php if(count($datas) > 0): ?>
                    <div align="center" class="col-md-12 table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <?php if (\Entrust::can('user-many-status')) : ?>
                        <th align="center">#</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">User Name</th>
                        <th align="center">Role</th>
                        <th align="center">Email</th>
                        <?php if (\Entrust::can('user-status')) : ?>
                        <th align="center">Status</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">Control</th>
                        <?php if (\Entrust::can('user-password')) : ?>
                        <th align="center">Reset Password</th>
                        <?php endif; // Entrust::can ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="center">
                                <?php $__currentLoopData = $data->role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user_role->slug == 'Develper'  && Auth::user()->role->first()->Develper =='Develper'): ?>
                                        <input type="checkbox" name="change_status[]"
                                               id="<?php echo e($data->slug); ?>" value="<?php echo e($data->slug); ?>">
                                    <?php elseif( $user_role->slug == 'Develper'  &&  Auth::user()->role->first()->slug !='Develper'): ?>
                                    <?php elseif( $data->slug == 'Develper'  ): ?>
                                    <?php elseif(Auth::user()->slug != $data->slug): ?>
                                        <input type="checkbox" name="change_status[]"
                                               id="<?php echo e($data->slug); ?>" value="<?php echo e($data->slug); ?>">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td align="center"><?php echo e($data->username); ?></td>
                            <td align="center">
                                <?php $__currentLoopData = $data->role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    [<?php echo e($user_role->name); ?>],
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td align="center"><?php echo e($data->email); ?></td>
                            <?php if (\Entrust::can('user-status')) : ?>
                            <td align="center">
                                <?php if($user_role->slug == 'Develper'  && Auth::user()->role->first()->Develper =='Develper'): ?>
                                    <?php if($data->status ==1): ?>
                                        <a href="<?php echo e(url('/admin/user/change_status/'.$data->slug)); ?>"><i
                                                    class="btn btn-danger ace-icon fa fa-close"> Dactive</i></a>
                                    <?php elseif($data->status ==0): ?>
                                        <a href="<?php echo e(url('/admin/user/change_status/'.$data->slug)); ?>"><i
                                                    class="btn btn-primary ace-icon fa fa-check-circle"> Active</i></a>
                                    <?php endif; ?>
                                <?php elseif( $user_role->slug == 'Develper'  &&  Auth::user()->role->first()->slug !='Develper'): ?>
                                    on permission to do this
                                <?php elseif( $data->slug == 'Develper'  ): ?>
                                    on permission to do this
                                <?php elseif(Auth::user()->slug != $data->slug): ?>
                                    <?php if($data->status ==1): ?>
                                        <a href="<?php echo e(url('/admin/user/change_status/'.$data->slug)); ?>"><i
                                                    class="btn btn-danger ace-icon fa fa-close"> Dactive</i></a>
                                    <?php elseif($data->status ==0): ?>
                                        <a href="<?php echo e(url('/admin/user/change_status/'.$data->slug)); ?>"><i
                                                    class="btn btn-primary ace-icon fa fa-check-circle"> Active</i></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <?php endif; // Entrust::can ?>
                            <td align="center">
                                <?php if($user_role->slug == 'Develper'  && Auth::user()->role->first()->Develper =='Develper'): ?>
                                    <?php if (\Entrust::can('user-edit')) : ?>
                                    <a href="<?php echo e(url('/admin/user/edit/'.$data->slug)); ?>"><i
                                                class="btn btn-primary ace-icon fa fa-edit bigger-120  edit"
                                                data-id=""> Edit</i></a>
                                    <?php endif; // Entrust::can ?>
                                    <?php if (\Entrust::can('user-delete')) : ?>
                                    <button type="button" id="<?php echo e($data->slug); ?>" onclick="selectItem('<?php echo e($data->slug); ?>')" class="btn btn-sm btn-danger ace-icon fa fa-remove bigger-120  edit" data-toggle="modal" data-target="#modal-danger">
                                        Delete
                                    </button>
                                    <?php endif; // Entrust::can ?>

                                <?php elseif( $user_role->slug == 'Develper'  &&  Auth::user()->role->first()->slug !='Develper'): ?>
                                    on permission to do this
                                <?php elseif( $data->slug == 'Develper'  ): ?>
                                    on permission to do this
                                <?php elseif(Auth::user()->slug != $data->slug): ?>
                                    <?php if (\Entrust::can('user-edit')) : ?>
                                    <a href="<?php echo e(url('/admin/user/edit/'.$data->slug)); ?>"><i
                                                class="btn btn-primary ace-icon fa fa-edit bigger-120  edit"
                                                data-id=""> Edit</i></a>
                                    <?php endif; // Entrust::can ?>
                                    <?php if (\Entrust::can('user-delete')) : ?>
                                    <button type="button" id="<?php echo e($data->slug); ?>" onclick="selectItem('<?php echo e($data->slug); ?>')" class="btn btn-sm btn-danger ace-icon fa fa-remove bigger-120  edit" data-toggle="modal" data-target="#modal-danger">
                                        Delete
                                    </button>
                                    <?php endif; // Entrust::can ?>
                                <?php endif; ?>
                            </td>
                            <?php if (\Entrust::can('user-password')) : ?>
                            <td>
                                <?php if($user_role->slug == 'Develper'  && Auth::user()->role->first()->Develper =='Develper'): ?>
                                    <a href="<?php echo e(url('admin/user/change_password/'.$data->slug)); ?>"
                                       class="btn btn-success">Reset Password</a>
                                <?php elseif( $user_role->slug == 'Develper'  &&  Auth::user()->role->first()->slug !='Develper'): ?>
                                    on permission to do this
                                <?php elseif( $data->slug == 'Develper'  ): ?>
                                    on permission to do this
                                <?php elseif(Auth::user()->slug != $data->slug): ?>
                                    <a href="<?php echo e(url('admin/user/change_password/'.$data->slug)); ?>"
                                       class="btn btn-success"> Reset Password</a>
                                <?php endif; ?>
                            </td>
                            <?php endif; // Entrust::can ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <?php if (\Entrust::can('user-many-status')) : ?>
                        <th align="center">#</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">User Name</th>
                        <th align="center">Role</th>
                        <th align="center">Email</th>
                        <?php if (\Entrust::can('user-status')) : ?>
                        <th align="center">Status</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">Control</th>
                        <?php if (\Entrust::can('user-password')) : ?>
                        <th align="center">Reset Password</th>
                        <?php endif; // Entrust::can ?>
                    </tr>
                    </tfoot>
                </table>
                    </div>
                <?php else: ?>
                    <div align="center">There is no Data to show</div>
                <?php endif; ?>
            </div>
            <!-- /.box-body -->
        </div>
        </form>
    </section>
    <div class="modal modal-danger fade" id="modal-danger">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Delete</h4>
                </div>
                <form id="user_delete" action="" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('delete')); ?>

                    <div class="modal-body">
                        <p>If you Delete it ,You will Delete Data in Permission & Role</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-outline">Delete</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo JsValidator::formRequest('Modules\ACl\Http\Requests\admin\User\UserStatusEditRequest','#status'); ?>

    <script>
        function selectItem(slug) {
            $('#user_delete').attr('action', "destroy/"+slug);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\Modules\ACL\Providers/../Resources/views/user/user_index.blade.php ENDPATH**/ ?>