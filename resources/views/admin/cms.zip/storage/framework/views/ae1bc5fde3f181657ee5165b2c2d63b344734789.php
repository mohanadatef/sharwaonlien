<script src="<?php echo e(asset('public/AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<!-- page script -->
<script>
    $(function () {
        $('#example1').DataTable()
        $('#example2').DataTable(
        {
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : true,
            "scrollX": true,
        })
    })
</script>
<?php /**PATH C:\xampp\htdocs\cms\resources\views/includes/admin/scripts_datatable.blade.php ENDPATH**/ ?>