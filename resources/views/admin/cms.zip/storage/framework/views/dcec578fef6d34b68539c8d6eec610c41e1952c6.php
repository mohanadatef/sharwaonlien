<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2019 <a href="#"> </a>.</strong> All rights
    reserved.
</footer>
<?php echo $__env->yieldContent('footer'); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/includes/admin/footer.blade.php ENDPATH**/ ?>