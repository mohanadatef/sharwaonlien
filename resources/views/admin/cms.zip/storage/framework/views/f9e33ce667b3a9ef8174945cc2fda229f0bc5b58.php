<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Left side column. contains the logo and sidebar -->
        <ul class="sidebar-menu" data-widget="tree">
            <?php if (\Entrust::can('core-data-list')) : ?>
            <li  class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>Core Data</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('size-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Size</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('size-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/size/index')); ?>"><i class="fa fa-group"></i><span>All Size</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('size-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/size/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Size</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('size-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/size/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Size Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('service-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Service</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('service-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/service/index')); ?>"><i class="fa fa-group"></i><span>All Service</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('service-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/service/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Service</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('service-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/service/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Service Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('category-service-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Category Service</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('category-service-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/category_service/index')); ?>"><i class="fa fa-group"></i><span>All Category Service</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('category-service-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/category_service/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Category Service</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('category-service-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/category_service/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Category Service Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('product-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Product</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('product-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/product/index')); ?>"><i class="fa fa-group"></i><span>All Product</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('product-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/product/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Product</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('product-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/product/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Product Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('item-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Item</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('item-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/item/index')); ?>"><i class="fa fa-group"></i><span>All Item</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('item-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/item/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Item</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('item-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/item/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Item Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('vacance-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Vacance</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('vacance-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/vacance/index')); ?>"><i class="fa fa-group"></i><span>All Vacance</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('vacance-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/vacance/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Vacance</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('vacance-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/vacance/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Vacance Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('media-center-list')) : ?>
            <li class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>Media Center</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('news-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>News</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('news-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/news/index')); ?>"><i class="fa fa-group"></i><span>All News</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('news-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/news/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add News</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('news-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/news/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All News Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('client-list')) : ?>
                    <li  class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Client</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('client-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/client/index')); ?>"><i class="fa fa-group"></i><span>All Client</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('client-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/client/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Client</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('client-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/client/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Client Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('gallery-list')) : ?>
                    <li  class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Gallery</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('gallery-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/gallery/index')); ?>"><i class="fa fa-group"></i><span>All Gallery</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('gallery-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/gallery/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Gallery</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('gallery-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/gallery/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Gallery Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('album-list')) : ?>
                    <li  class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Album</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('album-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/album/index')); ?>"><i class="fa fa-group"></i><span>All Album</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('album-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/album/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Album</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('album-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/album/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Album Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('setting-list')) : ?>
            <li  class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>Setting</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('home-slider-list')) : ?>
                    <li  class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Home Slider</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('home-slider-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/home_slider/index')); ?>"><i class="fa fa-group"></i><span>All Home Slider</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('home-slider-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/home_slider/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Home Slide</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('home-slider-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/home_slider/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Home Slide Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('setting-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Setting</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('setting-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/setting/index')); ?>"><i class="fa fa-group"></i><span>Setting</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('about-us-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>About US</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('about-us-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/about_us/index')); ?>"><i class="fa fa-group"></i><span>About US</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('contact-us-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Contact US</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('contact-us-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/contact_us/index')); ?>"><i class="fa fa-group"></i><span>Contact US</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('acl-list')) : ?>
            <li  class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>ACL</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('user-list')) : ?>
                    <li  class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>User</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('user-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i class="fa fa-group"></i><span>All User</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('user-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/user/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add User</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('user-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/user/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All User Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('role-list')) : ?>
                    <li  class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Role</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('role-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/role/index')); ?>"><i class="fa fa-group"></i><span>All Role</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('role-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/role/create')); ?>"><i
                                            class="fa fa-group"></i><span>Add Rloe</span></a></li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('role-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/role/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Role Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('permission-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>Permission</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul  class="treeview-menu">
                            <?php if (\Entrust::can('permission-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/permission/index')); ?>"><i class="fa fa-group"></i><span>All Permission</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('permission-index-delete')) : ?>
                            <li><a href="<?php echo e(url('/admin/permission/index/delete')); ?>"><i
                                            class="fa fa-group"></i><span>All Permission Delete</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
<?php echo $__env->yieldContent('main-sidebar'); ?>
<?php /**PATH C:\xampp\htdocs\cms\resources\views/includes/admin/main-sidebar.blade.php ENDPATH**/ ?>