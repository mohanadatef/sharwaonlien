<aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
        <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
        
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
        <!-- Home tab content -->
        <div class="tab-pane" id="control-sidebar-home-tab">
 

        </div>
        <!-- /.tab-pane -->
        <!-- Stats tab content -->
    
    <!-- /.tab-pane -->
        <!-- Settings tab content -->
    
    <!-- /.tab-pane -->
    </div>
</aside>
<?php echo $__env->yieldContent('setting_header'); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/includes/admin/setting_header.blade.php ENDPATH**/ ?>