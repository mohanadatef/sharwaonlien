<?php

return [
    'name' => 'MediaCenter'
];
