<?php

return [
    'name' => 'CoreData'
];
