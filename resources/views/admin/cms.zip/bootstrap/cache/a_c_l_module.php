<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ACL\\Providers\\ACLServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ACL\\Providers\\ACLServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);