<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MediaCenter\\Providers\\MediaCenterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MediaCenter\\Providers\\MediaCenterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);