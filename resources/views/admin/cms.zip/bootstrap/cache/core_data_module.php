<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CoreData\\Providers\\CoreDataServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CoreData\\Providers\\CoreDataServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);